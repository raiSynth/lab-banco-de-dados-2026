USE hotel;

-- HOSPEDES

INSERT INTO hospede
(nome, cpf, telefone, email, data_nascimento, data_cadastro, data_atualizacao)
VALUES
('João Silva','11111111111','61999990001','joao@email.com','1990-01-15',NOW(),NOW()),
('Maria Souza','11111111112','61999990002','maria@email.com','1992-03-20',NOW(),NOW()),
('Pedro Santos','11111111113','61999990003','pedro@email.com','1988-07-11',NOW(),NOW()),
('Ana Lima','11111111114','61999990004','ana@email.com','1995-09-05',NOW(),NOW()),
('Carlos Oliveira','11111111115','61999990005','carlos@email.com','1987-02-28',NOW(),NOW()),
('Fernanda Costa','11111111116','61999990006','fernanda@email.com','1993-10-13',NOW(),NOW()),
('Lucas Almeida','11111111117','61999990007','lucas@email.com','1991-12-01',NOW(),NOW()),
('Juliana Rocha','11111111118','61999990008','juliana@email.com','1998-04-22',NOW(),NOW()),
('Gabriel Pereira','11111111119','61999990009','gabriel@email.com','1989-06-09',NOW(),NOW()),
('Patricia Gomes','11111111120','61999990010','patricia@email.com','1994-08-18',NOW(),NOW()),
('Rafael Martins','11111111121','61999990011','rafael@email.com','1990-05-14',NOW(),NOW()),
('Beatriz Melo','11111111122','61999990012','beatriz@email.com','1997-11-30',NOW(),NOW()),
('Bruno Castro','11111111123','61999990013','bruno@email.com','1986-01-10',NOW(),NOW()),
('Larissa Dias','11111111124','61999990014','larissa@email.com','1999-02-17',NOW(),NOW()),
('Thiago Lopes','11111111125','61999990015','thiago@email.com','1992-07-27',NOW(),NOW()),
('Camila Ribeiro','11111111126','61999990016','camila@email.com','1996-03-08',NOW(),NOW()),
('Felipe Carvalho','11111111127','61999990017','felipe@email.com','1985-09-21',NOW(),NOW()),
('Amanda Nunes','11111111128','61999990018','amanda@email.com','1991-10-25',NOW(),NOW()),
('Diego Barros','11111111129','61999990019','diego@email.com','1988-04-14',NOW(),NOW()),
('Vanessa Moraes','11111111130','61999990020','vanessa@email.com','1995-12-19',NOW(),NOW());

-- QUARTOS 

INSERT INTO quarto
(numero,andar,capacidade,tipo,valor_diaria,status,data_cadastro,data_atualizacao)
VALUES
(101,1,2,'Standard',150,'Disponivel',NOW(),NOW()),
(102,1,2,'Standard',150,'Disponivel',NOW(),NOW()),
(103,1,3,'Luxo',250,'Disponivel',NOW(),NOW()),
(104,1,4,'Familia',350,'Disponivel',NOW(),NOW()),
(105,1,2,'Standard',150,'Disponivel',NOW(),NOW()),
(201,2,2,'Standard',170,'Disponivel',NOW(),NOW()),
(202,2,2,'Luxo',280,'Disponivel',NOW(),NOW()),
(203,2,3,'Luxo',280,'Disponivel',NOW(),NOW()),
(204,2,4,'Familia',380,'Disponivel',NOW(),NOW()),
(205,2,2,'Standard',170,'Disponivel',NOW(),NOW()),
(301,3,2,'Luxo',300,'Disponivel',NOW(),NOW()),
(302,3,2,'Luxo',300,'Disponivel',NOW(),NOW()),
(303,3,3,'Premium',450,'Disponivel',NOW(),NOW()),
(304,3,4,'Premium',500,'Disponivel',NOW(),NOW()),
(305,3,2,'Luxo',300,'Disponivel',NOW(),NOW()),
(401,4,2,'Premium',550,'Disponivel',NOW(),NOW()),
(402,4,2,'Premium',550,'Disponivel',NOW(),NOW()),
(403,4,3,'Premium',600,'Disponivel',NOW(),NOW()),
(404,4,4,'Master',800,'Disponivel',NOW(),NOW()),
(405,4,2,'Master',850,'Disponivel',NOW(),NOW());

-- FUNCIONARIOS 

INSERT INTO funcionario
(nome,cargo,telefone,salario,data_cadastro,data_atualizacao)
VALUES
('José Ramos','Recepcionista','61988880001',2500,NOW(),NOW()),
('Mariana Alves','Recepcionista','61988880002',2500,NOW(),NOW()),
('Ricardo Silva','Gerente','61988880003',7000,NOW(),NOW()),
('Paula Mendes','Camareira','61988880004',2200,NOW(),NOW()),
('André Souza','Camareiro','61988880005',2200,NOW(),NOW()),
('Roberta Lima','Supervisora','61988880006',4500,NOW(),NOW()),
('Eduardo Costa','Recepcionista','61988880007',2500,NOW(),NOW()),
('Tatiane Rocha','Camareira','61988880008',2200,NOW(),NOW()),
('Leonardo Dias','Manutenção','61988880009',3000,NOW(),NOW()),
('Priscila Martins','Financeiro','61988880010',4000,NOW(),NOW());

-- RESERVAS 

INSERT INTO reserva
(id_hospede,id_quarto,id_funcionario,data_reserva,data_checkin,data_checkout,qtd_hospedes,valor_total,data_cadastro,data_atualizacao)
VALUES
(1,1,1,'2026-01-01','2026-01-10','2026-01-12',2,300,NOW(),NOW()),
(2,2,2,'2026-01-02','2026-01-15','2026-01-17',2,300,NOW(),NOW()),
(3,3,1,'2026-01-03','2026-01-18','2026-01-20',3,500,NOW(),NOW()),
(4,4,2,'2026-01-04','2026-01-21','2026-01-23',4,700,NOW(),NOW()),
(5,5,1,'2026-01-05','2026-01-25','2026-01-27',2,300,NOW(),NOW()),
(6,6,2,'2026-01-06','2026-02-01','2026-02-03',2,340,NOW(),NOW()),
(7,7,3,'2026-01-07','2026-02-04','2026-02-06',2,560,NOW(),NOW()),
(8,8,3,'2026-01-08','2026-02-07','2026-02-09',3,560,NOW(),NOW()),
(9,9,1,'2026-01-09','2026-02-10','2026-02-12',4,760,NOW(),NOW()),
(10,10,2,'2026-01-10','2026-02-13','2026-02-15',2,340,NOW(),NOW()),
(11,11,1,'2026-01-11','2026-02-16','2026-02-18',2,600,NOW(),NOW()),
(12,12,2,'2026-01-12','2026-02-19','2026-02-21',2,600,NOW(),NOW()),
(13,13,3,'2026-01-13','2026-02-22','2026-02-24',3,900,NOW(),NOW()),
(14,14,3,'2026-01-14','2026-02-25','2026-02-27',4,1000,NOW(),NOW()),
(15,15,1,'2026-01-15','2026-03-01','2026-03-03',2,600,NOW(),NOW()),
(16,16,2,'2026-01-16','2026-03-04','2026-03-06',2,1100,NOW(),NOW()),
(17,17,1,'2026-01-17','2026-03-07','2026-03-09',2,1100,NOW(),NOW()),
(18,18,2,'2026-01-18','2026-03-10','2026-03-12',3,1200,NOW(),NOW()),
(19,19,3,'2026-01-19','2026-03-13','2026-03-15',4,1600,NOW(),NOW()),
(20,20,3,'2026-01-20','2026-03-16','2026-03-18',2,1700,NOW(),NOW()),
(1,2,1,'2026-03-20','2026-04-01','2026-04-03',2,300,NOW(),NOW()),
(2,3,2,'2026-03-21','2026-04-04','2026-04-06',2,500,NOW(),NOW()),
(3,4,1,'2026-03-22','2026-04-07','2026-04-09',4,700,NOW(),NOW()),
(4,5,2,'2026-03-23','2026-04-10','2026-04-12',2,300,NOW(),NOW()),
(5,6,1,'2026-03-24','2026-04-13','2026-04-15',2,340,NOW(),NOW());

-- PAGAMENTOS 

INSERT INTO pagamento
(id_reserva,data_pagamento,valor,forma_pagamento,status_pagamento,data_cadastro,data_atualizacao)
VALUES
(1,'2026-01-10',300,'Cartao','Pago',NOW(),NOW()),
(2,'2026-01-15',300,'Pix','Pago',NOW(),NOW()),
(3,'2026-01-18',500,'Dinheiro','Pago',NOW(),NOW()),
(4,'2026-01-21',700,'Cartao','Pago',NOW(),NOW()),
(5,'2026-01-25',300,'Pix','Pago',NOW(),NOW()),
(6,'2026-02-01',340,'Cartao','Pago',NOW(),NOW()),
(7,'2026-02-04',560,'Pix','Pago',NOW(),NOW()),
(8,'2026-02-07',560,'Dinheiro','Pago',NOW(),NOW()),
(9,'2026-02-10',760,'Cartao','Pago',NOW(),NOW()),
(10,'2026-02-13',340,'Pix','Pago',NOW(),NOW()),
(11,'2026-02-16',600,'Cartao','Pago',NOW(),NOW()),
(12,'2026-02-19',600,'Pix','Pago',NOW(),NOW()),
(13,'2026-02-22',900,'Cartao','Pago',NOW(),NOW()),
(14,'2026-02-25',1000,'Pix','Pago',NOW(),NOW()),
(15,'2026-03-01',600,'Dinheiro','Pago',NOW(),NOW()),
(16,'2026-03-04',1100,'Cartao','Pago',NOW(),NOW()),
(17,'2026-03-07',1100,'Pix','Pago',NOW(),NOW()),
(18,'2026-03-10',1200,'Cartao','Pago',NOW(),NOW()),
(19,'2026-03-13',1600,'Pix','Pago',NOW(),NOW()),
(20,'2026-03-16',1700,'Cartao','Pago',NOW(),NOW()),
(21,'2026-04-01',300,'Pix','Pago',NOW(),NOW()),
(22,'2026-04-04',500,'Cartao','Pago',NOW(),NOW()),
(23,'2026-04-07',700,'Pix','Pago',NOW(),NOW()),
(24,'2026-04-10',300,'Dinheiro','Pago',NOW(),NOW()),
(25,'2026-04-13',340,'Cartao','Pago',NOW(),NOW());