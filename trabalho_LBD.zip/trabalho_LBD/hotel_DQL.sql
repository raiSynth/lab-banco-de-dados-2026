USE hotel;

-- AVG 

SELECT AVG(valor_diaria) AS media_diarias
FROM quarto;

SELECT AVG(salario) AS media_salarios
FROM funcionario;


-- MAX 

SELECT MAX(valor_diaria) AS maior_diaria
FROM quarto;

SELECT MAX(valor) AS maior_pagamento
FROM pagamento;


-- MIN 

SELECT MIN(valor_diaria) AS menor_diaria
FROM quarto;

SELECT MIN(valor) AS menor_pagamento
FROM pagamento;


-- COUNT (CONTAGEM)

SELECT COUNT(*) AS total_hospedes
FROM hospede;

SELECT COUNT(*) AS total_reservas
FROM reserva;

SELECT COUNT(*) AS total_quartos
FROM quarto;


-- SUM 

SELECT SUM(valor) AS total_arrecadado
FROM pagamento;

SELECT SUM(salario) AS total_salarios
FROM funcionario;


-- JOIN (RELATÓRIOS)

SELECT
    r.id_reserva,
    h.nome AS hospede,
    q.numero AS quarto,
    f.nome AS funcionario,
    r.data_checkin,
    r.data_checkout,
    r.valor_total
FROM reserva r
INNER JOIN hospede h
    ON r.id_hospede = h.id_hospede
INNER JOIN quarto q
    ON r.id_quarto = q.id_quarto
INNER JOIN funcionario f
    ON r.id_funcionario = f.id_funcionario;


SELECT
    p.id_pagamento,
    h.nome AS hospede,
    p.valor,
    p.forma_pagamento,
    p.status_pagamento
FROM pagamento p
INNER JOIN reserva r
    ON p.id_reserva = r.id_reserva
INNER JOIN hospede h
    ON r.id_hospede = h.id_hospede;


SELECT
    h.nome,
    SUM(p.valor) AS total_gasto
FROM hospede h
INNER JOIN reserva r
    ON h.id_hospede = r.id_hospede
INNER JOIN pagamento p
    ON r.id_reserva = p.id_reserva
GROUP BY h.nome;


SELECT
    q.numero,
    COUNT(r.id_reserva) AS quantidade_reservas
FROM quarto q
INNER JOIN reserva r
    ON q.id_quarto = r.id_quarto
GROUP BY q.numero;


SELECT
    forma_pagamento,
    SUM(valor) AS total_recebido
FROM pagamento
GROUP BY forma_pagamento;
